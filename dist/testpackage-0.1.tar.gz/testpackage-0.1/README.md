# testpackage
This library was created as an example to create your own Python package

## building this package
python setup.py sdist

## installling package
pip install git+https://github.com/altazietsman/<repository name>.git

