from setuptools import setup, find_packages

setup(name='testpackage',
      version='0.1',
      description='Testing installation of Package',
      url='#',
      author='auth',
      author_email='author@email.com',
      license='MIT',
      packages=['testpackage'],
      zip_safe=False)
